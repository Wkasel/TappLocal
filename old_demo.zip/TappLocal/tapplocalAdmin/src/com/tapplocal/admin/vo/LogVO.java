package com.tapplocal.admin.vo;

public class LogVO {
	
	public String date;
	public long flag;
	public long views;
	public long directions;
	public long noThanks;
	public long close;
	public long moreDeals;
	public long usedFar;
	public long usedOk;
	public long merchant;
}
