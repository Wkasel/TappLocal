package com.tapplocal.admin.service;

import org.nextframework.service.GenericService;

import com.tapplocal.admin.bean.Developer;


public class DeveloperService extends GenericService<Developer>{
//
}