package com.tapplocal.admin.service;

import org.nextframework.service.GenericService;

import com.tapplocal.admin.bean.Store;


public class StoreService extends GenericService<Store>{
//
}