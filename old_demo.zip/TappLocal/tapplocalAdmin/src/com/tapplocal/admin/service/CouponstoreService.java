package com.tapplocal.admin.service;

import org.nextframework.service.GenericService;

import com.tapplocal.admin.bean.Couponstore;


public class CouponstoreService extends GenericService<Couponstore>{
//
}