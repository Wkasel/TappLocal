package com.tapplocal.admin.dao;

import org.nextframework.bean.annotation.Bean;
import org.nextframework.persistence.GenericDAO;

import com.tapplocal.admin.bean.Representative;

@Bean
public class RepresentativeDAO extends GenericDAO<Representative>{

	
}
