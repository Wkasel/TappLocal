package com.tapplocal.admin.dao;

import org.nextframework.bean.annotation.Bean;
import org.nextframework.persistence.GenericDAO;

import com.tapplocal.admin.bean.Developer;

@Bean
public class DeveloperDAO extends GenericDAO<Developer>{


	
}
