package com.tapplocal.admin.dao;

import org.nextframework.bean.annotation.Bean;
import org.nextframework.persistence.GenericDAO;

import com.tapplocal.admin.bean.Couponstore;

@Bean
public class CouponstoreDAO extends GenericDAO<Couponstore>{

	
}
