package com.tapplocal.admin.dao;

import org.nextframework.bean.annotation.Bean;
import org.nextframework.persistence.GenericDAO;

import com.tapplocal.admin.bean.Merchant;

@Bean
public class MerchantDAO extends GenericDAO<Merchant>{

	
}
