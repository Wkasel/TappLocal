//
//  Test.m
//  SDK
//
//  Created by Guilherme Carvalho on 14/10/10.
//  Copyright 2010 Konkix. All rights reserved.
//

#import "Test.h"


@implementation Test

+(int)sum:(int)a :(int)b
{
	return a+b;
}

@end
