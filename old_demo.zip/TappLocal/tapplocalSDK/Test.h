//
//  Test.h
//  SDK
//
//  Created by Guilherme Carvalho on 14/10/10.
//  Copyright 2010 Konkix. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Test : NSObject {

}

+(int)sum:(int)a :(int)b;

@end
