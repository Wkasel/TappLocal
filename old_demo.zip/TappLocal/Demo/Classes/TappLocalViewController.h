//
//  GameClockViewController.h
//  GameClock
//
//  Created by Guilherme Carvalho on 16/07/10.
//  Copyright Konkix 2010. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HomeView.h"

@interface TappLocalViewController : UIViewController {

	HomeView* hView;
}



@end

