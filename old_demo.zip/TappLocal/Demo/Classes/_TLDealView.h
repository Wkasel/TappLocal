//
//  UpcomingNormalView.h
//  GameClock
//
//  Created by Guilherme Carvalho on 29/07/10.
//  Copyright 2010 Konkix. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "_TLFontLabel.h"
#import "_TLColorUtils.h"
#import "_TLResourceManager.h"
#import "_TLRMSTracker.h"
#import "_TLCoupon.h"
#import "_TLTappLocalView.h"
#import "_TLRMSTracker.h"

@interface _TLDealView : NSObject {
	
	id tl;
		
	_TLTappLocalView* mother;
	UIImageView* bg;
	
	UINavigationBar* top;
	UIButton* close;

	_TLFontLabel* special;
	UIButton* merchantlogoFrame;	
	UIButton* merchantlogo;	

	_TLFontLabel* text1;
	_TLFontLabel* text2;
	_TLFontLabel* text3;
	
	UIButton* directions;
	UIButton* nothanks;
	UIButton* moredeals;
	
	UIButton* taptouse;
	
	_TLFontLabel* text4;
	_TLFontLabel* text5;
	
	_TLCoupon* coupon;
	
	BOOL isBuilt;
}

-(void) configure:(id) parent;
-(void) merchantClick;
-(void) closeClick;
-(void) tapToUseClick;
-(void) moreDealsClick;
-(void) noThanksClick;

@end
