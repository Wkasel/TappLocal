//
//  PastView.h
//  GameClock
//
//  Created by Guilherme Carvalho on 29/07/10.
//  Copyright 2010 Konkix. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "_TLFontLabel.h"
#import "_TLColorUtils.h"
#import "_TLResourceManager.h"
#import "TappLocalAPI.h"
#import "Test.h"

@interface HomeView : NSObject {
	UIViewController* controller;
	
	UIView* mother;
	UIImageView* bg;
	UIImageView* logo;	
	
	_TLFontLabel* text;
	_TLFontLabel* link;
	UIView* underline;
	UIButton* button;

	_TLFontLabel* boxtext;

	BOOL isBuilt;
	
	TappLocalAPI* tl;
}

-(void) configure:(UIViewController*) parent;

@end
