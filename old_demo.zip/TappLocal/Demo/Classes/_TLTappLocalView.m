//
//  TappLocalView.m
//  TappLocal
//
//  Created by Guilherme Carvalho on 22/08/10.
//  Copyright 2010 Konkix. All rights reserved.
//

#import "_TLTappLocalView.h"


@implementation _TLTappLocalView

@end
